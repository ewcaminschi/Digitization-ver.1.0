const dialog = require('electron').remote.dialog;

var fs = require('fs');