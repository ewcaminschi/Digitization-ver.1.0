import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import{Invoice} from '../models/invoice.model';

@Injectable()
export class InvoiceValidatorService {
  readonly rootUrl = 'http://localhost:54411/'

  constructor(private http:HttpClient) { }

  postInvoice(inv :Invoice){
    const headers = new HttpHeaders().set('content-type', 'application/json');

    const body: Invoice = {
      InvoiceId:inv.InvoiceId,
      Client:inv.Client,
      From:inv.From,
      To:inv.To,
      InvoiceNr:inv.InvoiceNr,
      Date:inv.Date,
      Line:inv.Line,
      Value:inv.Value,
      Ledger:inv.Ledger,
      Status:inv.Status,
      PdfSrc:inv.PdfSrc
      
    }
  return this.http.post<Invoice>(this.rootUrl +'api/Invoices',body,{headers});
  }

  getInvoiceList():Observable<Invoice[]>{
    return this.http.get<Invoice[]>(this.rootUrl +'api/Invoices').map(res => {
      return res;
    });
    
  
  }
}
