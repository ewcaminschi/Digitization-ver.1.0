import { TestBed, inject } from '@angular/core/testing';

import { InvoicesMainService } from './invoices-main.service';

describe('InvoicesMainService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InvoicesMainService]
    });
  });

  it('should be created', inject([InvoicesMainService], (service: InvoicesMainService) => {
    expect(service).toBeTruthy();
  }));
});
