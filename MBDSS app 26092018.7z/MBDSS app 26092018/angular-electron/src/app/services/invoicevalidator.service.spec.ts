import { TestBed, inject } from '@angular/core/testing';

import { InvoiceValidatorService } from './invoicevalidator.service';

describe('InvoicevalidatorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InvoiceValidatorService]
    });
  });

  it('should be created', inject([InvoiceValidatorService], (service: InvoiceValidatorService) => {
    expect(service).toBeTruthy();
  }));
});
