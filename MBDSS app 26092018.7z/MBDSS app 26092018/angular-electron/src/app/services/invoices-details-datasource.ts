import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { Observable, BehaviorSubject } from "rxjs";
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { InvoiceDetails } from '@app/models/invoice-details.model';
import { InvoicesDetailsService } from '@app/services/invoices-details.service';



export class InvoicesDetailsDataSource implements DataSource<InvoiceDetails>{

    private invoicesDetailsSubject = new BehaviorSubject<InvoiceDetails[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private invoicesDetailsService : InvoicesDetailsService){

    }

    connect(collectionViewer: CollectionViewer): Observable<InvoiceDetails[]> {
        console.log("Connecting data source");
        return this.invoicesDetailsSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.invoicesDetailsSubject.complete();
        this.loadingSubject.complete();
    }

    loadInvoiceDetails(){
        this.loadingSubject.next(true);

        this.invoicesDetailsService.findAllInvoicesDetails().pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(iDetails => this.invoicesDetailsSubject.next(iDetails));

    }

    loadInvoiceDetailsByMainId(idInvoice:string){
        this.loadingSubject.next(true);

        this.invoicesDetailsService.findInvoicesDetailsByMainId(idInvoice).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(iDetails => this.invoicesDetailsSubject.next(iDetails));

        
    }







}
