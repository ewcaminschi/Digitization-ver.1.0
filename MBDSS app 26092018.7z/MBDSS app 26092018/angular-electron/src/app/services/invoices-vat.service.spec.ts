import { TestBed, inject } from '@angular/core/testing';

import { InvoicesVatService } from './invoices-vat.service';

describe('InvoicesVatService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InvoicesVatService]
    });
  });

  it('should be created', inject([InvoicesVatService], (service: InvoicesVatService) => {
    expect(service).toBeTruthy();
  }));
});
