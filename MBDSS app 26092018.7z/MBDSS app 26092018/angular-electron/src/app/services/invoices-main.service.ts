import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { InvoiceMain } from '@app/models/invoice-main.models';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { InvoiceMainCollection } from '@app/models/invoice-main-collection.model';

@Injectable()
export class InvoicesMainService {
  
  private readonly API_URL = 'https://localhost:44377/invoicesmain/';

  constructor(private http: HttpClient) {

   }
   findAllInvoiceMain(pageNumber:number, pageSize:number):Observable<InvoiceMain[]> {

    return this.http.get<InvoiceMainCollection>(this.API_URL, {
      params: new HttpParams()         
          .set('limit', pageSize.toString())
     //     .set('offset', pageNumber.toString())
  }).pipe(
  
        map(res => { res['payload']= res.value;
                return res['payload'];
              }));
   }
   
   findAllInvoicesMain():Observable<InvoiceMain[]> {

    return this.http.get<InvoiceMainCollection>(this.API_URL).pipe(
  
        map(res => { res['payload']= res.value;
                return res['payload'];
              }));
   }

   findInvoiceMainById(idInvoice:string): Observable<InvoiceMain[]> {
    return this.http.get<InvoiceMainCollection>(this.API_URL).pipe(
  
      map(res => { res['payload']= res.value.filter(x => x.idInvoice === idInvoice);
              return res['payload'];
            }));
   }
}
