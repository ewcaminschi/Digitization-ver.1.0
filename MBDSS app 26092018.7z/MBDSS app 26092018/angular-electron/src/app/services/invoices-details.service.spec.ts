import { TestBed, inject } from '@angular/core/testing';

import { InvoicesDetailsService } from './invoices-details.service';

describe('InvoicesDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InvoicesDetailsService]
    });
  });

  it('should be created', inject([InvoicesDetailsService], (service: InvoicesDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
