import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { Observable, BehaviorSubject } from "rxjs";
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { InvoiceMain } from '@app/models/invoice-main.models';
import { InvoicesMainService } from "@app/services/invoices-main.service";

export class InvoicesMainDataSource implements DataSource<InvoiceMain>{

    private invoicesMainSubject = new BehaviorSubject<InvoiceMain[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private invoicesMainService : InvoicesMainService){}

   

    connect(collectionViewer: CollectionViewer): Observable<InvoiceMain[]> {
        console.log("Connecting data source");
        return this.invoicesMainSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.invoicesMainSubject.complete();
        this.loadingSubject.complete();
    }

    loadInvoicesMain(){
        this.loadingSubject.next(true);

        this.invoicesMainService.findAllInvoicesMain().pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(iMain => this.invoicesMainSubject.next(iMain));

        
    }

    loadInvoiceMain(pageNumber:number, pageSize:number){
        this.loadingSubject.next(true);

        this.invoicesMainService.findAllInvoiceMain(pageNumber,pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(iMain => this.invoicesMainSubject.next(iMain));

        
    }

    loadInvoiceMainById(idInvoice:string){

            this.loadingSubject.next(true);

            this.invoicesMainService.findInvoiceMainById(idInvoice).pipe(
                    catchError(() => of([])),
                    finalize(() => this.loadingSubject.next(false))
                )
                .subscribe(iMain => this.invoicesMainSubject.next(iMain));

    }


}