import { InvoiceVatCollection } from './../models/invoice-vat-collection.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InvoiceVat } from '@app/models/invoice-vat.model';
import { map } from 'rxjs/operators';

@Injectable()
export class InvoicesVatService {

    private readonly API_URL = 'https://localhost:44377/invoicesvat/';

    constructor(private http: HttpClient) {

    }

    findAllInvoicesVat(): Observable<InvoiceVat[]> {

        return this.http.get<InvoiceVatCollection>(this.API_URL)
            .pipe(

                map(res => {
                    res['payload'] = res.value;
                    return res['payload'];
                }));
    }

    findInvoiceVatById(idInvoice): Observable<InvoiceVat[]> {

        return this.http.get<InvoiceVat[]>(this.API_URL + idInvoice)
            .pipe(
                map(res => res.filter['payload'])
            );
    }

    findInvoicesVatByMainId(idInvoice:string): Observable<InvoiceVat[]> {

        return this.http.get<InvoiceVatCollection>(this.API_URL)
            .pipe(

                map(res => {
                    res['payload'] = res.value.filter(x => x.idInvoice === idInvoice);
                    return res['payload'];
                }));
        }



 //TO DO
 //Post Method
 //Update / Patch Method
 //Delete Method

}


