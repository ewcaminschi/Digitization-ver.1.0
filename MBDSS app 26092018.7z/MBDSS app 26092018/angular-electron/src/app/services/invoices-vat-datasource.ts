import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { Observable, BehaviorSubject } from "rxjs";
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { InvoiceVat } from "@app/models/invoice-vat.model";
import { InvoicesVatService } from "@app/services/invoices-vat.service";

export class InvoicesVatDataSource implements DataSource<InvoiceVat>{

    private invoicesVatSubject = new BehaviorSubject<InvoiceVat[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private invoicesVatService : InvoicesVatService){}

    connect(collectionViewer: CollectionViewer): Observable<InvoiceVat[]> {
        console.log("Connecting data source");
        return this.invoicesVatSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.invoicesVatSubject.complete();
        this.loadingSubject.complete();
    }

    loadInvoiceVat() {

        this.loadingSubject.next(true);

        this.invoicesVatService.findAllInvoicesVat().pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(iVat => this.invoicesVatSubject.next(iVat));

    }

    loadInvoicesVatByMainId(idInvoice:string){
        this.loadingSubject.next(true);

        this.invoicesVatService.findInvoicesVatByMainId(idInvoice).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(iVat => this.invoicesVatSubject.next(iVat));

    }


}