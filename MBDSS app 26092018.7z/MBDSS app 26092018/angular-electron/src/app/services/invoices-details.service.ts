import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { InvoiceDetails } from '@app/models/invoice-details.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { InvoiceDetailsCollection } from '@app/models/invoice-details-collection.model';


@Injectable()

export class InvoicesDetailsService {

    private readonly API_URL = 'https://localhost:44377/invoicesdetails/';

    constructor(private http: HttpClient) {

    }

    //Get Methods
    findAllInvoicesDetails(): Observable<InvoiceDetails[]> {

        return this.http.get<InvoiceDetailsCollection>(this.API_URL).pipe(

            map(res => {
            res['payload'] = res.value;
                return res['payload'];
            }));
    }

    findInvoiceDetailsById(idInvoiceDetails): Observable<InvoiceDetails[]> {

        return this.http.get<InvoiceDetailsCollection>(this.API_URL + idInvoiceDetails).pipe(

            map(res => {
            res['payload'] = res.value;
                return res['payload'];
            }));
    }



    findInvoicesDetailsByMainId(idInvoice: string): Observable<InvoiceDetails[]> {

        return this.http.get<InvoiceDetailsCollection>(this.API_URL).pipe(
            map(res => {
                res['payload'] = res.value.filter(x =>x.idInvoice === idInvoice);
                    return res['payload'];
                }));
        
    }

    //TO DO
    //Post Method
    //Update / Patch Method
    //Delete Method

}
