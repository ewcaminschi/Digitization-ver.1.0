import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Invoice} from '../models/invoice.model';
import {HttpClient,HttpHeaders, HttpErrorResponse} from '@angular/common/http';
declare var $: any;
@Injectable()
export class DataService {
  private readonly API_URL = 'http://localhost:55086/api/invoice/';

  dataChange: BehaviorSubject<Invoice[]> = new BehaviorSubject<Invoice[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  constructor (private httpClient: HttpClient) {}

  get data(): Invoice[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllInvoices(): void {
    this.httpClient.get<Invoice[]>(this.API_URL).subscribe(data => {
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      console.log (error.name + ' ' + error.message);
      });
  }

  showNotification(from, align){
    const type = ['','info','success','warning','danger','primary'];

    // const color = Math.floor((Math.random() * 5) + 1);

    $.notify({
        icon: "notifications",
        message: "Saved to Database"

    },{
        type: type['primary'],
        timer: 2000,
        placement: {
            from: from,
            align: align
        }
    });
}
  
  addInvoice(invoice :Invoice){
    const headers = new HttpHeaders().set('content-type', 'application/json');

    const body: Invoice = {
      InvoiceId:invoice.InvoiceId,
      Client:invoice.Client,
      From:invoice.From,
      To:invoice.To,
      InvoiceNr:invoice.InvoiceNr,
      Date:invoice.Date,
      Line:invoice.Line,
      Value:invoice.Value,
      Ledger:invoice.Ledger,
      Status:invoice.Status,
      PdfSrc:invoice.PdfSrc
      
      
    }
  return this.httpClient.post<Invoice>(this.API_URL,body,{headers}).subscribe(invoice => {
    this.dialogData = invoice;
    console.log('Successfully added', 3000);
    },
    (err: HttpErrorResponse) => {
     console.log('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
     });
  }

  // UPDATE, PUT METHOD
  updateInvoice(invoice: Invoice): void {
    this.httpClient.put(this.API_URL + invoice.InvoiceId, invoice).subscribe(invoice => {
        this.dialogData = invoice;
       // this.toasterService.showToaster('Successfully edited', 3000);
       this.showNotification('bottom','right');

       console.log('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
      //  this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      console.log('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

 

/* REAL LIFE CRUD Methods I've used in my projects. ToasterService uses Material Toasts for displaying messages:
    // ADD, POST METHOD
    addItem(kanbanItem: KanbanItem): void {
    this.httpClient.post(this.API_URL, kanbanItem).subscribe(data => {
      this.dialogData = kanbanItem;
      this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
      this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
    });
   }
    // UPDATE, PUT METHOD
     updateItem(kanbanItem: KanbanItem): void {
    this.httpClient.put(this.API_URL + kanbanItem.id, kanbanItem).subscribe(data => {
        this.dialogData = kanbanItem;
        this.toasterService.showToaster('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
  // DELETE METHOD
  deleteItem(id: number): void {
    this.httpClient.delete(this.API_URL + id).subscribe(data => {
      console.log(data['']);
        this.toasterService.showToaster('Successfully deleted', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
*/
}
