import { Component, OnInit } from '@angular/core';
import {Message} from '../models/message';

@Component({
  selector: 'app-dialogflow',
  templateUrl: './dialogflow.component.html',
  styleUrls: ['./dialogflow.component.scss']
})
export class DialogflowComponent implements OnInit {
  public message : Message;
  public messages : Message[];


  constructor(){
    this.message = new Message('', '/assets/img/user.png');
    this.messages = [
      new Message('Welcome to Mason Breese Assistant!', '/assets/img/bot.png', new Date())
    ];
}

 

  ngOnInit() {
  }

}
