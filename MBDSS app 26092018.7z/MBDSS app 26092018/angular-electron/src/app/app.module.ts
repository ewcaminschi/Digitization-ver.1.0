import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import { RouterModule } from '@angular/router';
import {CdkTableModule} from '@angular/cdk/table';
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';

import { AppComponent } from './app.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { TableListComponent } from './table-list/table-list.component';
import { TypographyComponent } from './typography/typography.component';
import { IconsComponent } from './icons/icons.component';
import { MapsComponent } from './maps/maps.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { UpgradeComponent } from './upgrade/upgrade.component';
import { DialogflowComponent } from './dialogflow/dialogflow.component';
import { InvoiceValidatorComponent } from './invoice-validator/invoice-validator.component';
import { InvoiceDialogComponent } from './invoice-dialog/invoice-dialog.component';
import { ValidatorComponent } from './validator/validator.component';
import { SaveDialogComponent } from '@app/components/save-dialog/save-dialog.component';
//import { PdfViewerModule } from 'ng2-pdf-viewer';
//import { PdfviewComponent } from './pdfview/pdfview.component';
import { PdfViewerComponent } from './pdf-viewer/pdf-viewer.component';
import {SimplePdfViewerModule} from 'simple-pdf-viewer';
import { EcoFabSpeedDialModule } from '@ecodev/fab-speed-dial';


import { MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,} from '@angular/material';
import {MatFormFieldModule} from '@angular/material/form-field';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import { InvoicesVatService } from '@app/services/invoices-vat.service';
import { InvoicesMainService } from '@app/services/invoices-main.service';
import {InvoicesDetailsService} from './services/invoices-details.service'
import {InvoiceValidatorService} from './services/invoicevalidator.service';
import {DataService} from './services/data.service';
import {DialogflowService} from './services/dialogflow.service';
import { TestService } from '@app/services/test.service';
import { InvoicesMainEditDialogComponent } from './components/invoices-main-edit-dialog/invoices-main-edit-dialog.component';
import { InvoicesDetailsEditDialogComponent } from '@app/components/invoices-details-edit-dialog/invoices-details-edit-dialog.component';
import { InvoicesVatEditDialogComponent } from '@app/components/invoices-vat-edit-dialog/invoices-vat-edit-dialog.component';
import { InvoiceValidateDialogComponent } from '@app/components/invoice-validate-dialog/invoice-validate-dialog.component';
import { InvoiceRejectDialogComponent } from '@app/components/invoice-reject-dialog/invoice-reject-dialog.component';




@NgModule({
  exports: [
    CdkTableModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule, 
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
  ],
  declarations: []
})
export class MaterialModule {}


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    UserProfileComponent,
    TableListComponent,
    TypographyComponent,
    IconsComponent,
    MapsComponent,
    NotificationsComponent,
    UpgradeComponent,
    DialogflowComponent,
    InvoiceValidatorComponent,
    InvoiceDialogComponent,
    ValidatorComponent,
    //PdfviewComponent,
    PdfViewerComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    MaterialModule,
    MatFormFieldModule,
    NoopAnimationsModule,
    MatDialogModule,
    EcoFabSpeedDialModule,
    //PdfViewerModule,
    SimplePdfViewerModule
  ],
  providers: [
    TestService,
    DialogflowService, 
    InvoiceValidatorService,
    DataService,
    InvoicesMainService,
    InvoicesDetailsService,
    InvoicesVatService,
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    InvoiceDialogComponent,
    SaveDialogComponent,
    InvoicesMainEditDialogComponent,
    InvoicesDetailsEditDialogComponent,
    InvoicesVatEditDialogComponent,
    InvoiceValidateDialogComponent,
    InvoiceRejectDialogComponent,
  ]
})
export class AppModule { }
