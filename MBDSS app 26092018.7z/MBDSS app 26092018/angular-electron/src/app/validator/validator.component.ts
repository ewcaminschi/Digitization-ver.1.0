import { InvoicesMainService } from './../services/invoices-main.service';
import { Component, OnInit } from '@angular/core';
import { InvoiceMain } from '@app/models/invoice-main.models';

@Component({
  selector: 'app-validator',
  templateUrl: './validator.component.html',
  styleUrls: ['./validator.component.scss']
})
export class ValidatorComponent implements OnInit {
  
  constructor() { }
  
  ngOnInit() {
    
  }

}