import {Component, Inject, OnInit, ViewEncapsulation} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import{Invoice} from '../models/invoice.model';
import {FormBuilder, Validators, FormGroup,FormControl} from "@angular/forms";
import {DataService} from '../services/data.service';


@Component({
    selector: 'invoice-dialog',
    templateUrl: './invoice-dialog.component.html',
    styleUrls: ['./invoice-dialog.component.scss']
})
export class InvoiceDialogComponent implements OnInit {


    constructor(
        public dialogRef: MatDialogRef<InvoiceDialogComponent>,
        public dataService : DataService, 
        @Inject(MAT_DIALOG_DATA) public data:Invoice) { }

    ngOnInit() {

    }
    formControl = new FormControl('', [
        Validators.required
        // Validators.from,
    ]);
    
    getErrorMessage() {
        return this.formControl.hasError('required') ? 'Required field' :
          this.formControl.hasError('From') ? 'Not a valid input' :
            '';
    }
    
    submit() {
        // emppty stuff
    }

    save() {
        this.dataService.updateInvoice(this.data);
    
    }

    close() {
        this.dialogRef.close();
    }

}