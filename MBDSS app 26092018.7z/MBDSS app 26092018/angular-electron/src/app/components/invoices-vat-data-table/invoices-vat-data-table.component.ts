import { MatDialogConfig } from '@angular/material';
import { Component, OnInit, ElementRef } from '@angular/core';
import { InvoicesVatDataSource } from '@app/services/invoices-vat-datasource';
import { InvoicesVatService } from '@app/services/invoices-vat.service';
import { MatDialog} from '@angular/material';
import { InvoicesVatEditDialogComponent } from '@app/components/invoices-vat-edit-dialog/invoices-vat-edit-dialog.component';
import { InvoiceVat } from '@app/models/invoice-vat.model';

@Component({
  selector: 'app-invoices-vat-data-table',
  templateUrl: './invoices-vat-data-table.component.html',
  styleUrls: ['./invoices-vat-data-table.component.scss']
})
export class InvoicesVatDataTableComponent implements OnInit {

  selectedRow;

  invoicesVatDataSource: InvoicesVatDataSource;

  displayedColumns = ['descriptionVat', 'percentageVat', 'valueVat', 'ledger'];

  constructor(private invoicesDetailsService: InvoicesVatService, private dialog: MatDialog) {

  }

 ngOnInit() {
   
   this.invoicesVatDataSource = new InvoicesVatDataSource(this.invoicesDetailsService);
   //this.invoicesVatDataSource.loadInvoiceVat();
  }

  loadInvoicesVatByMainId(idInvoice:string){

    this.invoicesVatDataSource.loadInvoicesVatByMainId(idInvoice);

  }

   //open edit dialog
   openEditDialog(row:InvoiceVat , descriptionVat:string, percentageVat:number, valueVat:number, ledger:number): void {
     this.selectedRow = row;
     const dialogConfig = new MatDialogConfig();

     dialogConfig.autoFocus = true;
     dialogConfig.hasBackdrop= false;
     dialogConfig.disableClose = false;
     dialogConfig.data = {
      descriptionVat,
      percentageVat,
      valueVat,
      ledger      
};
     const dialogRef = this.dialog.open(InvoicesVatEditDialogComponent, dialogConfig);

     dialogRef.afterClosed().subscribe( res => {
       console.log(res);
      });
    }
}
