import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesVatDataTableComponent } from './invoices-vat-data-table.component';

describe('InvoicesVatDataTableComponent', () => {
  let component: InvoicesVatDataTableComponent;
  let fixture: ComponentFixture<InvoicesVatDataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesVatDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesVatDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
