import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesDetailsEditDialogComponent } from './invoices-details-edit-dialog.component';

describe('InvoicesDetailsEditDialogComponent', () => {
  let component: InvoicesDetailsEditDialogComponent;
  let fixture: ComponentFixture<InvoicesDetailsEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesDetailsEditDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesDetailsEditDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
