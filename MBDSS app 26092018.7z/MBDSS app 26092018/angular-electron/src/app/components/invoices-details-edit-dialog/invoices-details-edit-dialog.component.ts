import { Component, OnInit, Inject, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { InvoiceDetails } from '@app/models/invoice-details.model';

@Component({
  selector: 'app-invoices-details-edit-dialog',
  templateUrl: './invoices-details-edit-dialog.component.html',
  styleUrls: ['./invoices-details-edit-dialog.component.scss']
})
export class InvoicesDetailsEditDialogComponent implements OnInit {

  form: FormGroup;
  description: string;

  constructor(
    private fb: FormBuilder,
    private matDialogRef: MatDialogRef<InvoicesDetailsEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA){ description, quantity, unitValue, discount, total, ledger }: InvoiceDetails ) {

      this.description = description;
  
  
      this.form = fb.group({
        description: [description, Validators.required],
        quantity: [quantity, Validators.required],
        unitValue: [unitValue, Validators.required],
        discount: [discount, Validators.required],
        total: [total, Validators.required],
        
        ledger: [ledger, Validators.required]
       // releasedAt: [moment(), Validators.required],
        
      });
  
    }

ngOnInit() {
const matDialogConfig: MatDialogConfig = new MatDialogConfig();


matDialogConfig.position = { left: `552px`, top: `180px` };
matDialogConfig.width = '800px';
matDialogConfig.height = '310px';
this.matDialogRef.updateSize(matDialogConfig.width, matDialogConfig.height);
this.matDialogRef.updatePosition(matDialogConfig.position);

}
cancel(): void {
this.matDialogRef.close(null);
}
}
