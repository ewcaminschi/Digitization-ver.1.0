import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { MatDialogConfig } from '@angular/material';
import { InvoicesDetailsDataSource } from '@app/services/invoices-details-datasource';
import { InvoicesDetailsService } from '@app/services/invoices-details.service';
import { InvoiceDetails } from '@app/models/invoice-details.model';
import { InvoicesDetailsEditDialogComponent } from '@app/components/invoices-details-edit-dialog/invoices-details-edit-dialog.component';

@Component({
  selector: 'app-invoices-details-data-table',
  templateUrl: './invoices-details-data-table.component.html',
  styleUrls: ['./invoices-details-data-table.component.scss']
})
export class InvoicesDetailsDataTableComponent implements OnInit {

  selectedRow;

  invoicesDetailsDataSource: InvoicesDetailsDataSource;
 
  private displayedColumns = [ 'description', 'quantity', 'unitValue', 'discount', 'total', 'ledger'];

  constructor(private invoicesDetailsService: InvoicesDetailsService,  private dialog: MatDialog) {

   }

  ngOnInit() {
    
    this.invoicesDetailsDataSource = new InvoicesDetailsDataSource(this.invoicesDetailsService);
   // this.invoicesDetailsDataSource.loadInvoiceDetails();


  }
  loadInvoicesDetails(){

    this.invoicesDetailsDataSource.loadInvoiceDetails();

  }

  loadInvoicesDetailsByMainId(idInvoice:string){

    this.invoicesDetailsDataSource.loadInvoiceDetailsByMainId(idInvoice);

  }

 //open edit dialog
 openEditDialog(row, description: string, quantity: number, unitValue:number, discount:number, total:number, ledger:number): void {
  this.selectedRow = row;
  const dialogConfig = new MatDialogConfig();

  dialogConfig.autoFocus = true;
  dialogConfig.hasBackdrop= false;
  dialogConfig.disableClose = false;
  dialogConfig.data = {
   description,
   quantity,
   unitValue,
   discount,
   total,
   ledger      
};

  const dialogRef = this.dialog.open(InvoicesDetailsEditDialogComponent, dialogConfig);

  dialogRef.afterClosed().subscribe( res => {
    console.log(res);
   });
 }

}
