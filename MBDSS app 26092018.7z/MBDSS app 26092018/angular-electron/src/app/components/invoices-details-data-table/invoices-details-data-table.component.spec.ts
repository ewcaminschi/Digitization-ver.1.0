import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesDetailsDataTableComponent } from './invoices-details-data-table.component';

describe('InvoicesDetailsDataTableComponent', () => {
  let component: InvoicesDetailsDataTableComponent;
  let fixture: ComponentFixture<InvoicesDetailsDataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesDetailsDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesDetailsDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
