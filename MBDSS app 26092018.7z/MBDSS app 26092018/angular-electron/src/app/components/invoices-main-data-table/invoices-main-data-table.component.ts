import { Component, OnInit } from '@angular/core';
import { InvoicesMainDataSource } from '@app/services/invoices-main-datasource';
import { InvoicesMainEditDialogComponent } from '@app/components/invoices-main-edit-dialog/invoices-main-edit-dialog.component';
import { MatDialogConfig } from '@angular/material';
import { MatDialog } from '@angular/material';
import { InvoicesMainService } from '@app/services/invoices-main.service';

@Component({
  selector: 'app-invoices-main-data-table',
  templateUrl: './invoices-main-data-table.component.html',
  styleUrls: ['./invoices-main-data-table.component.scss']
})
export class InvoicesMainDataTableComponent implements OnInit {

  selectedRow;

  invoicesMainDataSource: InvoicesMainDataSource;

  private displayedColumns = ['supplier', 'reciever', 'number', 'date', 'account', 'currency']

  constructor(private invoicesMainService: InvoicesMainService, private dialog: MatDialog) {

  }

  ngOnInit() {

    this.invoicesMainDataSource = new InvoicesMainDataSource(this.invoicesMainService);
    // this.invoicesMainDataSource.loadInvoicesMain();
  }

  loadInvoicesMainById(idInvoice: string) {

    this.invoicesMainDataSource.loadInvoiceMainById(idInvoice);

  }

  //open edit dialog
  openEditDialog(row, client: string, supplier: string, reciever: string, number: number, dateTime: Date, account: number, currency: string): void {
    this.selectedRow = row;
    const dialogConfig = new MatDialogConfig();

    dialogConfig.autoFocus = true;
    dialogConfig.hasBackdrop = false;
    dialogConfig.disableClose = false;
    dialogConfig.data = {
      client,
      supplier,
      reciever,
      number,
      dateTime,
      account,
      currency
    };
    const dialogRef = this.dialog.open(InvoicesMainEditDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(res => {
      console.log(res);
    });
  }



}
