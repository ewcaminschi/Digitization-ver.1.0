import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesMainDataTableComponent } from './invoices-main-data-table.component';

describe('InvoicesMainDataTableComponent', () => {
  let component: InvoicesMainDataTableComponent;
  let fixture: ComponentFixture<InvoicesMainDataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesMainDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesMainDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
