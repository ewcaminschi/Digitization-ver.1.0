import { InvoicesMainDataTableComponent } from './../invoices-main-data-table/invoices-main-data-table.component';
import { InvoicesMainService } from './../../services/invoices-main.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { InvoiceMain } from '@app/models/invoice-main.models';
import { InvoicesMainDataSource } from '@app/services/invoices-main-datasource';
import { MatPaginator } from '@angular/material';
import { tap } from 'rxjs/operators';
import { InvoicesVatDataTableComponent } from '@app/components/invoices-vat-data-table/invoices-vat-data-table.component';
import { InvoicesDetailsDataTableComponent } from '@app/components/invoices-details-data-table/invoices-details-data-table.component';

@Component({
  selector: 'app-invoices-validation',
  templateUrl: './invoices-validation.component.html',
  styleUrls: ['./invoices-validation.component.scss']
})
export class InvoicesValidationComponent implements OnInit {

  selectedRow: InvoiceMain;
  row: InvoiceMain;

  invoicesMainDataSource: InvoicesMainDataSource;
  
  private displayedColumns = ['client','number'];
 
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('tableInvoiceMain') invoiceMainDataTable: InvoicesMainDataTableComponent;
  @ViewChild('tableInvoiceDetails') invoiceDetailsDataTable: InvoicesDetailsDataTableComponent;
  @ViewChild('tableInvoiceVat') invoiceVatDataTable: InvoicesVatDataTableComponent;
 
  constructor(private invoicesMainService :InvoicesMainService) { 

  }

  ngOnInit() {
    
    this.invoicesMainDataSource = new InvoicesMainDataSource(this.invoicesMainService);
    this.invoicesMainDataSource.loadInvoicesMain();

  }

  ngAfterViewInit() {
    this.paginator.page
        .pipe(
            tap(() => this.loadInvoicesMainPage())
        )
        .subscribe();
}

  loadInvoicesMainPage() {
    this.invoicesMainDataSource.loadInvoiceMain(
    this.paginator.pageIndex,
    this.paginator.pageSize);
}

  //Load data in tables.
  onRowClicked(row) {
    this.selectedRow = row;
    this.invoiceMainDataTable.loadInvoicesMainById(row.idInvoice);
    this.invoiceVatDataTable.loadInvoicesVatByMainId(row.idInvoice);
    this.invoiceDetailsDataTable.loadInvoicesDetailsByMainId(row.idInvoice);
   

    console.log('Row clicked: ', row);
  }


  onRefresh(){
   // ToDo
   this.loadInvoicesMainPage();
  }

  onValidate(){
   
   this.row= this.selectedRow;
   console.log(this.row);
  }

  onReject(row){
  // ToDo
  console.log(row);
  }

}
