import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesValidationComponent } from './invoices-validation.component';

describe('InvoicesValidationComponent', () => {
  let component: InvoicesValidationComponent;
  let fixture: ComponentFixture<InvoicesValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesValidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
