import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceValidateDialogComponent } from './invoice-validate-dialog.component';

describe('InvoiceValidateDialogComponent', () => {
  let component: InvoiceValidateDialogComponent;
  let fixture: ComponentFixture<InvoiceValidateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceValidateDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceValidateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
