import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-validate-dialog',
  templateUrl: './invoice-validate-dialog.component.html',
  styleUrls: ['./invoice-validate-dialog.component.scss']
})
export class InvoiceValidateDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
