import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule,ReactiveFormsModule, } from '@angular/forms';
import { MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, 
  MatSortModule, MatTableModule,MatDialogModule,MatIconModule,MatButtonModule,MatDatepickerModule,MatNativeDateModule } from "@angular/material";
 
import {MatFormFieldModule} from '@angular/material/form-field';
import {SimplePdfViewerModule} from 'simple-pdf-viewer';
import { EcoFabSpeedDialModule } from '@ecodev/fab-speed-dial';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MessageListComponent } from './message-list/message-list.component';
import { MessageItemComponent } from './message-item/message-item.component';
import { MessageFormComponent } from './message-form/message-form.component';
import { ValidatorDatatableComponent } from './validator-datatable/validator-datatable.component';
import { SaveDialogComponent } from './save-dialog/save-dialog.component';
import { ValidatorPdfViewerComponent } from './validator-pdf-viewer/validator-pdf-viewer.component';
import { InvoicesMainDataTableComponent } from './invoices-main-data-table/invoices-main-data-table.component';
import { InvoicesDetailsDataTableComponent } from './invoices-details-data-table/invoices-details-data-table.component';
import { InvoicesVatDataTableComponent } from './invoices-vat-data-table/invoices-vat-data-table.component';
import { InvoicesValidationComponent } from './invoices-validation/invoices-validation.component';
import { InvoicesDetailsEditDialogComponent } from './invoices-details-edit-dialog/invoices-details-edit-dialog.component';
import { InvoicesMainEditDialogComponent } from './invoices-main-edit-dialog/invoices-main-edit-dialog.component';
import { InvoicesVatEditDialogComponent } from './invoices-vat-edit-dialog/invoices-vat-edit-dialog.component';
import { InvoiceValidateDialogComponent } from './invoice-validate-dialog/invoice-validate-dialog.component';
import { InvoiceRejectDialogComponent } from './invoice-reject-dialog/invoice-reject-dialog.component';




@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatPaginatorModule, 
    MatProgressSpinnerModule, 
    MatSortModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    SimplePdfViewerModule,
    EcoFabSpeedDialModule, 
  ],
  declarations: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    MessageListComponent,
    MessageItemComponent,
    MessageFormComponent,
    ValidatorDatatableComponent,
    SaveDialogComponent,
    ValidatorPdfViewerComponent,
    InvoicesMainDataTableComponent,
    InvoicesDetailsDataTableComponent,
    InvoicesVatDataTableComponent,
    InvoicesValidationComponent,
    InvoicesDetailsEditDialogComponent,
    InvoicesMainEditDialogComponent,
    InvoicesVatEditDialogComponent,
    InvoiceValidateDialogComponent,
    InvoiceRejectDialogComponent,
    
   
   
  ],
  exports: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    MessageListComponent,
    MessageItemComponent,
    MessageFormComponent,
    ValidatorDatatableComponent,
    InvoicesMainDataTableComponent,
    InvoicesDetailsDataTableComponent,
    InvoicesVatDataTableComponent,
    InvoicesValidationComponent,
    SaveDialogComponent,
    ValidatorPdfViewerComponent,
    InvoicesDetailsEditDialogComponent,
    InvoicesMainEditDialogComponent,
    InvoicesVatEditDialogComponent,
    InvoiceValidateDialogComponent,
    InvoiceRejectDialogComponent,
    
    
  ]
})
export class ComponentsModule { }
