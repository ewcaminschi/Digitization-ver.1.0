import { Component, OnInit, Inject, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { InvoiceMain } from '@app/models/invoice-main.models';

@Component({
  selector: 'app-invoices-main-edit-dialog',
  templateUrl: './invoices-main-edit-dialog.component.html',
  styleUrls: ['./invoices-main-edit-dialog.component.scss']
})
export class InvoicesMainEditDialogComponent implements OnInit {

  form: FormGroup;
  client: string;

  constructor(
    private fb: FormBuilder,
    private matDialogRef: MatDialogRef<InvoicesMainEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) { client, supplier, reciever, number, dateTime, account, currency }: InvoiceMain) {

    this.client = client;


    this.form = fb.group({
      supplier: [supplier, Validators.required],
      reciever: [reciever, Validators.required],
      number: [number, Validators.required],
      date: [dateTime, Validators.required],
      account: [account, Validators.required],
      currency: [currency, Validators.required]
      // releasedAt: [moment(), Validators.required],

    });

  }

  ngOnInit() {
    const matDialogConfig: MatDialogConfig = new MatDialogConfig();


    matDialogConfig.position = { left: `552px`, top: `68px` };
    matDialogConfig.width = '800px';
    matDialogConfig.height = '110px';
    this.matDialogRef.updateSize(matDialogConfig.width, matDialogConfig.height);
    this.matDialogRef.updatePosition(matDialogConfig.position);

  }

  cancel(): void {
    this.matDialogRef.close(null);
  }

}