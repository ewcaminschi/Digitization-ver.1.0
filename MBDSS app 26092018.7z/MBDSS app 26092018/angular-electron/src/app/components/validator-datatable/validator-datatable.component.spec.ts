import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatorDatatableComponent } from './validator-datatable.component';

describe('ValidatorDatatableComponent', () => {
  let component: ValidatorDatatableComponent;
  let fixture: ComponentFixture<ValidatorDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidatorDatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidatorDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
