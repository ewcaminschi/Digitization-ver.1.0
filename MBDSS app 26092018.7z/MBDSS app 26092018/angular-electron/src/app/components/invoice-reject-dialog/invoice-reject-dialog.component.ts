import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-reject-dialog',
  templateUrl: './invoice-reject-dialog.component.html',
  styleUrls: ['./invoice-reject-dialog.component.scss']
})
export class InvoiceRejectDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
