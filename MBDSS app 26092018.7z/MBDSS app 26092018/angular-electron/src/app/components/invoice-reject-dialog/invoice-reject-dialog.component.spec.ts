import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceRejectDialogComponent } from './invoice-reject-dialog.component';

describe('InvoiceRejectDialogComponent', () => {
  let component: InvoiceRejectDialogComponent;
  let fixture: ComponentFixture<InvoiceRejectDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceRejectDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceRejectDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
