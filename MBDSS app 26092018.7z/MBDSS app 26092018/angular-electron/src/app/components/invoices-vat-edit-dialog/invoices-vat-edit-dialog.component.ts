import { Component, OnInit, ElementRef, Inject } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { FormGroup, Validators } from '@angular/forms';
import { InvoiceVat } from '@app/models/invoice-vat.model';

@Component({
  selector: 'app-invoices-vat-edit-dialog',
  templateUrl: './invoices-vat-edit-dialog.component.html',
  styleUrls: ['./invoices-vat-edit-dialog.component.scss']
})
export class InvoicesVatEditDialogComponent implements OnInit {

  form: FormGroup;
  descriptionVat: string;
 

  constructor(
    private fb: FormBuilder,
    private matDialogRef: MatDialogRef<InvoicesVatEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA){ descriptionVat, percentageVat, valueVat, ledger }: InvoiceVat ) {

    this.descriptionVat = descriptionVat;


    this.form = fb.group({
      descriptionVat: [descriptionVat, Validators.required],
      percentageVat: [percentageVat, Validators.required],
      valueVat: [valueVat, Validators.required],
      ledger: [ledger, Validators.required]
     // releasedAt: [moment(), Validators.required],
      
    });

  }


  ngOnInit() {
    const matDialogConfig: MatDialogConfig = new MatDialogConfig();


    matDialogConfig.position = { left: `552px`, top: `550px` };
    matDialogConfig.width = '800px';
    matDialogConfig.height = '310px';
    this.matDialogRef.updateSize(matDialogConfig.width, matDialogConfig.height);
    this.matDialogRef.updatePosition(matDialogConfig.position);




  }
  
  cancel(): void {
    this.matDialogRef.close(null);
  }
}
