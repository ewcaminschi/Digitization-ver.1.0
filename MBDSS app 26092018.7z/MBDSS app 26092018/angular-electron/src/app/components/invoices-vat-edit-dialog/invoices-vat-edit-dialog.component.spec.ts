import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicesVatEditDialogComponent } from './invoices-vat-edit-dialog.component';

describe('InvoicesVatEditDialogComponent', () => {
  let component: InvoicesVatEditDialogComponent;
  let fixture: ComponentFixture<InvoicesVatEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoicesVatEditDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicesVatEditDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
