import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import{Invoice} from '../../models/invoice.model';
import {FormBuilder, Validators, FormGroup,FormControl} from "@angular/forms";
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-save-dialog',
  templateUrl: './save-dialog.component.html',
  styleUrls: ['./save-dialog.component.scss']
})
export class SaveDialogComponent implements OnInit {
  
  ngOnInit() {

  }
  constructor(private dialogRef: MatDialogRef<SaveDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data: Invoice, private dataService: DataService) { }

onNoClick(): void {
this.dialogRef.close();
}

confirmSave(): void {
this.dataService.updateInvoice(this.data);
}

}
