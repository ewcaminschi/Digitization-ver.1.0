import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatorPdfViewerComponent } from './validator-pdf-viewer.component';

describe('ValidatorPdfViewerComponent', () => {
  let component: ValidatorPdfViewerComponent;
  let fixture: ComponentFixture<ValidatorPdfViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidatorPdfViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidatorPdfViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
