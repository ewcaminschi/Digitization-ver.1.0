import { Component, OnInit,ViewChild } from '@angular/core';
import {MatPaginator, MatSort} from '@angular/material';
import { MatTableDataSource} from '@angular/material';


@Component({
  selector: 'app-invoice-validator',
  templateUrl: './invoice-validator.component.html',
  styleUrls: ['./invoice-validator.component.scss']
})

  export class InvoiceValidatorComponent {
    
    displayedColumns = ['position', 'name', 'weight', 'symbol', 'fav',];
    dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
  
  
    @ViewChild(MatPaginator) paginator: MatPaginator;
    
    @ViewChild(MatSort) sort: MatSort;
  
    constructor() {
      
    }
  
    ngOnInit() {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  
    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
      this.dataSource.filter = filterValue;
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
  }
  
  export interface Element {
    name: string;
    position: number;
    weight: number;
    symbol: string;
    fav: string;
    color:string;
  }
  
  const ELEMENT_DATA: Element[] = [
    { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H', fav: "Yes",color: "red" },
    { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He', fav: "",color: "maroon" },
    { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li', fav: "",color: "orange" },
    { position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be', fav: "",color: "brown" },
    { position: 5, name: 'Boron', weight: 10.811, symbol: 'B', fav: "Yes",color: "olive" },
    { position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C', fav: "",color: "green" },
    { position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N', fav: "",color: "red" },
    { position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O', fav: "",color: "purple" },
    { position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F', fav: "",color: "red" },
    { position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne', fav: "",color: "red" },
    { position: 11, name: 'Sodium', weight: 22.9897, symbol: 'Na', fav: "",color: "black" },
    { position: 12, name: 'Magnesium', weight: 24.305, symbol: 'Mg', fav: "",color: "red" },
    { position: 13, name: 'Aluminum', weight: 26.9815, symbol: 'Al', fav: "",color: "red" },
    { position: 14, name: 'Silicon', weight: 28.0855, symbol: 'Si', fav: "",color: "red" },
    { position: 15, name: 'Phosphorus', weight: 30.9738, symbol: 'P', fav: "",color: "red" },
    { position: 16, name: 'Sulfur', weight: 32.065, symbol: 'S', fav: "",color: "aqua" },
    { position: 17, name: 'Chlorine', weight: 35.453, symbol: 'Cl', fav: "",color: "red" },
    { position: 18, name: 'Argon', weight: 39.948, symbol: 'Ar', fav: "",color: "red" },
    { position: 19, name: 'Potassium', weight: 39.0983, symbol: 'K', fav: "" ,color: "red"},
    { position: 20, name: 'Calcium', weight: 40.078, symbol: 'Ca', fav: "" ,color: "red"},
  ];