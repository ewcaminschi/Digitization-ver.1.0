import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceValidatorComponent } from './invoice-validator.component';

describe('InvoiceValidatorComponent', () => {
  let component: InvoiceValidatorComponent;
  let fixture: ComponentFixture<InvoiceValidatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceValidatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceValidatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
