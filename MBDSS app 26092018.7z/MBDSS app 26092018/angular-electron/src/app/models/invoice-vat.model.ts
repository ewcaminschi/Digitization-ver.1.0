import { Deserializable } from "@app/models/deserializable";

export class InvoiceVat implements  Deserializable{
    href: string;
    idInvoiceVat:string;
    idInvoice:string;
    descriptionVat: string;  
    percentageVat:number;
    valueVat:number;
    ledger:number;
    ledgerProbability: number;
    

    deserialize(input: any) {
       Object.assign(this, input);
       return this;
    }

}