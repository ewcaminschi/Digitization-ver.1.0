import { InvoiceVat } from '@app/models/invoice-vat.model';
import { Page } from '@app/models/page-collection.model';

export class InvoiceVatCollection {
href: string;
rel:string[];
offset: number;
limit: number;
size : number;
first?: Page;
previous?:Page;
next?:Page;
last?:Page;
value : InvoiceVat[];
    
}