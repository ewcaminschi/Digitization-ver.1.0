import { InvoiceVat } from './invoice-vat.model';
import { Deserializable } from "@app/models/deserializable";
import { InvoiceDetails } from "@app/models/invoice-details.model";

export class InvoiceMain implements  Deserializable{
    href: string;
    idInvoice:string;
    client:string;
    supplier:string;
    reciever:string;
    number:number;
    dateTime:Date;
    account:string;
    currency:string;
    path:string;
    fileName:string;
    invoiceStatus: number;
    validationUser:string;
    invoiceDetails: InvoiceDetails; //potential refactor
    invoiceVat: InvoiceVat; //potential refactor
    

    deserialize(input: any) {
       Object.assign(this, input);
       this.invoiceDetails = new InvoiceDetails().deserialize(input.invoiceDetails);
       this.invoiceVat = new InvoiceVat().deserialize(input.invoiceVat);
       
       return this;
    }

    getHeader() {
        return this.client + ' ' + this.supplier;
      }

}