//interface which provides an API for deserialization

export interface Deserializable {
    deserialize(input: any): this;
}