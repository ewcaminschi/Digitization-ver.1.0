import { Page } from '@app/models/page-collection.model';
import { InvoiceMain } from '@app/models/invoice-main.models';

export class InvoiceMainCollection {
href: string;
rel:string[];
offset: number;
limit: number;
size : number;
first?: Page;
previous?:Page;
next?:Page;
last?:Page;
value : InvoiceMain[];
    
}