import { Page } from '@app/models/page-collection.model';
import { InvoiceDetails } from '@app/models/invoice-details.model';

export class InvoiceDetailsCollection {
href: string;
rel:string[];
offset: number;
limit: number;
size : number;
first?: Page;
previous?:Page;
next?:Page;
last?:Page;
value : InvoiceDetails[];
    
}





