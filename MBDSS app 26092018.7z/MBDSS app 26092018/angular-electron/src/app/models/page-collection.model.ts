export class Page {
    href:string;
    rel:string[];
}