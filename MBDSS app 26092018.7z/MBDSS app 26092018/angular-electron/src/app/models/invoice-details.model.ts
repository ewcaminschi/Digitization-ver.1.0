import { Deserializable } from './deserializable';

export class InvoiceDetails implements Deserializable{
     href:string;
     idInvoiceDetails:string;
     idInvoice:string;
     lineNumber: number;
     description:string;
     quantity:number;
     unitValue:number;
     discount:number;
     total:number;
     ledger:number;
     detailsLedgerProbability:number;


     deserialize(input: any) {
        Object.assign(this, input);
        return this;
     }




}