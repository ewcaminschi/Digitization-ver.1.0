export class Invoice{
    InvoiceId:number;
    Client:string;
    From:string;
    To:string;
    InvoiceNr:string;
    Date:string;
    Line:string;
    Value:string;
    Ledger:string;
    Status:boolean;
    PdfSrc:string;
}
