﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace MBDAppWebApi.Migrations
{
    public partial class initialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DigitisationOutputs",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    OrganisationName = table.Column<string>(nullable: true),
                    SuplierName = table.Column<string>(nullable: true),
                    ClientName = table.Column<string>(nullable: true),
                    InvoiceNumber = table.Column<string>(nullable: true),
                    InvoiceDate = table.Column<DateTime>(nullable: true),
                    InvoiceLineDescription = table.Column<string>(nullable: true),
                    InvoiceLineValue = table.Column<decimal>(nullable: true),
                    InvoiceLineVat = table.Column<decimal>(nullable: true),
                    InvoiceLineQty = table.Column<decimal>(nullable: true),
                    InvoiceLineTotal = table.Column<decimal>(nullable: true),
                    InvoiceTotalExcludeVat = table.Column<decimal>(nullable: true),
                    InvoiceTotalVat = table.Column<decimal>(nullable: true),
                    InvoiceTotal = table.Column<decimal>(nullable: true),
                    Ledger = table.Column<int>(nullable: true),
                    LedgerProbability = table.Column<int>(nullable: true),
                    Status = table.Column<bool>(nullable: true),

                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DigitisationOutputs", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DigitisationOutputs");
        }
    }
}
