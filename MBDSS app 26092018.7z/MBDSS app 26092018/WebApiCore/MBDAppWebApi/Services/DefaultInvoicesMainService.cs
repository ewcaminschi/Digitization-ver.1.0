﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MBDAppWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace MBDAppWebApi.Services
{
    public class DefaultInvoicesMainService : IInvoicesMainService
    {
        private readonly MbdAppContext _context;
        private readonly IMapper _mapper;

        public DefaultInvoicesMainService(MbdAppContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PagedResults<InvoicesMainResource>> GetInvoicesMainAsync(
            PagingOptions pagingOptions, 
            SortOptions<InvoicesMainResource, InvoicesMainEntity> sortOptions,
            SearchOptions<InvoicesMainResource, InvoicesMainEntity> searchOptions, 
            CancellationToken ct)
        {
            IQueryable<InvoicesMainEntity> query = _context.InvoicesMain;

            //apply sort
            query = sortOptions.Apply(query);
            //apply search
            query = searchOptions.Apply(query);

            var size = await query.CountAsync(ct);

            var items = await query
                .Skip(pagingOptions.Offset.Value)
                .Take(pagingOptions.Limit.Value)
                .ProjectTo<InvoicesMainResource>(_mapper.ConfigurationProvider)
                .ToArrayAsync(ct);

            return new PagedResults<InvoicesMainResource>
            {
                Items = items,
                TotalSize = size
            };
        }

        public async Task<InvoicesMainResource> GetInvoicesMainByIdAsync(Guid id, CancellationToken ct)
        {
            var entity = await _context.InvoicesMain.SingleOrDefaultAsync(d => d.IdInvoice == id, ct);
            if (entity == null) return null;

            return _mapper.Map<InvoicesMainResource>(entity);
        }

        public Task<Guid> CreateInvoicesMainAsync(Guid userId, string client, string Supplier, string Reciever, string Number, DateTime? Date, string Account, string Currency, string Path, string FileName, int? InvoiceStatus, string ValidationUser, DateTimeOffset startAt, CancellationToken ct)
        {
            throw new NotImplementedException();
        }



    }
}
