﻿using MBDAppWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MBDAppWebApi.Services
{
    public interface IInvoicesVatService
    {
        Task<PagedResults<InvoicesVatResource>> GetInvoicesVatAsync(
            PagingOptions pagingOptions,
            SortOptions<InvoicesVatResource, InvoicesVatEntity> sortOptions,
            SearchOptions<InvoicesVatResource, InvoicesVatEntity> searchOptions,
            CancellationToken ct);

        Task<InvoicesVatResource> GetInvoicesVatByIdAsync(
            Guid id,
            CancellationToken ct);
    }
}
