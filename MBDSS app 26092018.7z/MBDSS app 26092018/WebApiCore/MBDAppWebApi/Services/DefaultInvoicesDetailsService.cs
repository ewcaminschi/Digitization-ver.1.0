﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MBDAppWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace MBDAppWebApi.Services
{
    public class DefaultInvoicesDetailsService : IInvoicesDetailsService
    {
        private readonly MbdAppContext _context;
        private readonly IMapper _mapper;

        public DefaultInvoicesDetailsService(MbdAppContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PagedResults<InvoicesDetailsResource>> GetInvoicesDetailsAsync(
            PagingOptions pagingOptions, 
            SortOptions<InvoicesDetailsResource, InvoicesDetailsEntity> sortOptions,
            SearchOptions<InvoicesDetailsResource, InvoicesDetailsEntity> searchOptions,
            CancellationToken ct)
        {
            IQueryable<InvoicesDetailsEntity> query = _context.InvoicesDetails;

            //apply sort
            query = sortOptions.Apply(query);
            //apply search
            query = searchOptions.Apply(query);

            var size = await query.CountAsync(ct);

            var items = await query
                .Skip(pagingOptions.Offset.Value)
                .Take(pagingOptions.Limit.Value)
                .ProjectTo<InvoicesDetailsResource>(_mapper.ConfigurationProvider)
                .ToArrayAsync(ct);

            return new PagedResults<InvoicesDetailsResource>
            {
                Items = items,
                TotalSize = size
            };

        }

        public async Task<InvoicesDetailsResource> GetInvoicesDetailsByIdAsync(
            Guid id, 
            CancellationToken ct)
        {
            var entity = await _context.InvoicesDetails.SingleOrDefaultAsync(d => d.IdInvoiceDetails  == id, ct);
            if (entity == null) return null;

            return _mapper.Map<InvoicesDetailsResource>(entity);
        }


        public async Task<Guid> CreateInvoicesDetailsAsync(
            Guid userId,
            Guid idInvoice, 
            int lineNumber, 
            string description, 
            int quantity, 
            decimal? unitValue, 
            decimal? discount, 
            decimal? total, 
            int? ledger, 
            decimal? ledgerProbability, 
            CancellationToken ct)
        {
            var invoiceMain = await _context.InvoicesMain
                .SingleOrDefaultAsync(i => i.IdInvoice == idInvoice, ct);
            if (invoiceMain == null) throw new ArgumentException("Invalid InvoicesMain id.");

            
            var id = Guid.NewGuid();
            
            var newInvoicesDetails = _context.InvoicesDetails.Add(new InvoicesDetailsEntity
            {
                IdInvoiceDetails = id,
                IdInvoice = idInvoice,
                LineNumber = lineNumber,
                Description = description,
                Quantity = quantity,
                UnitValue = unitValue,
                Discount = discount,
                Total = total,
                Ledger = ledger,
                LedgerProbability = ledgerProbability
            });

            var created = await _context.SaveChangesAsync(ct);
            if (created < 1)

                throw new InvalidOperationException("Could not create the invoices details.");



            return id;
        }

       
        

    }
}
