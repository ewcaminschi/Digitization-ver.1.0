﻿using MBDAppWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MBDAppWebApi.Services
{
    public interface IInvoicesDetailsService
    {
        Task<PagedResults<InvoicesDetailsResource>> GetInvoicesDetailsAsync(
            PagingOptions pagingOptions,
            SortOptions<InvoicesDetailsResource, InvoicesDetailsEntity> sortOptions,
            SearchOptions<InvoicesDetailsResource, InvoicesDetailsEntity> searchOptions,
            CancellationToken ct);

        Task<InvoicesDetailsResource> GetInvoicesDetailsByIdAsync(
            Guid id,
            CancellationToken ct);

        Task<Guid> CreateInvoicesDetailsAsync(
            Guid userId,
            Guid idInvoice,
            int lineNumber,
            String description,
            int quantity,
            Decimal? unitValue,
            Decimal? discount,
            Decimal? total,
            int? ledger,
            Decimal? ledgerProbability,
            CancellationToken ct);
    }
}

