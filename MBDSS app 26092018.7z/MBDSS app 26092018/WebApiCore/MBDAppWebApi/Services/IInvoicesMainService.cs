﻿using MBDAppWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MBDAppWebApi.Services
{
    public interface IInvoicesMainService
    {
        Task<PagedResults<InvoicesMainResource>> GetInvoicesMainAsync(
            PagingOptions pagingOptions,
            SortOptions<InvoicesMainResource, InvoicesMainEntity> sortOptions,
            SearchOptions<InvoicesMainResource, InvoicesMainEntity> searchOptions,
            CancellationToken ct);

        Task<InvoicesMainResource> GetInvoicesMainByIdAsync(
            Guid id,
            CancellationToken ct);

        Task<Guid> CreateInvoicesMainAsync(
            Guid userId,
            string client,           
            string Supplier, 
            string Reciever,
            string Number,
            DateTime? Date,
            string Account,
            string Currency,
            string Path,
            string FileName,
            int? InvoiceStatus,
            string ValidationUser,
            DateTimeOffset startAt,          
            CancellationToken ct);
    }
}
