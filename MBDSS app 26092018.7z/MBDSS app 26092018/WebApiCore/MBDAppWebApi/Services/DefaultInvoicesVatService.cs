﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MBDAppWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace MBDAppWebApi.Services
{
    public class DefaultInvoicesVatService : IInvoicesVatService
    {
        private readonly MbdAppContext _context;
        private readonly IMapper _mapper;

        public DefaultInvoicesVatService(MbdAppContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PagedResults<InvoicesVatResource>> GetInvoicesVatAsync(
            PagingOptions pagingOptions, 
            SortOptions<InvoicesVatResource,InvoicesVatEntity> sortOptions,
            SearchOptions<InvoicesVatResource, InvoicesVatEntity> searchOptions,
            CancellationToken ct)
        {
            IQueryable<InvoicesVatEntity> query = _context.InvoicesVat;

            //apply sort
            query = sortOptions.Apply(query);
            //apply search
            query = searchOptions.Apply(query);

            var size = await query.CountAsync(ct);

            var items = await query
                .Skip(pagingOptions.Offset.Value)
                .Take(pagingOptions.Limit.Value)
                .ProjectTo<InvoicesVatResource>(_mapper.ConfigurationProvider)
                .ToArrayAsync(ct);

            return new PagedResults<InvoicesVatResource>
            {
                Items = items,
                TotalSize = size
            };
        }

        public async Task<InvoicesVatResource> GetInvoicesVatByIdAsync(Guid id, CancellationToken ct)
        {
            var entity = await _context.InvoicesVat.SingleOrDefaultAsync(d => d.IdInvoiceVat == id, ct);
            if (entity == null) return null;

            return _mapper.Map<InvoicesVatResource>(entity);
        }
    }
}
