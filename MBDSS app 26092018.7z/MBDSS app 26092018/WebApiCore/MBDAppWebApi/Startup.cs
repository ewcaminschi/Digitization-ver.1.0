﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NJsonSchema;
using NSwag.AspNetCore;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using NSwag.SwaggerGeneration.Processors;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc.Formatters;

using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Versioning;
using MBDAppWebApi.Filters;
using MBDAppWebApi.Models;
using Microsoft.EntityFrameworkCore;
using MBDAppWebApi.Services;
using AutoMapper;
using MBDAppWebApi.Infrastructure;

namespace MBDAppWebApi
{
    public class Startup
    {
        private readonly int? _httpsPort;

        public Startup(IConfiguration configuration , IHostingEnvironment env)
        {
            Configuration = configuration;

            if (env.IsDevelopment())
            {
                var launchJsonConfig = new ConfigurationBuilder()
                    .SetBasePath(env.ContentRootPath)
                    .AddJsonFile("Properties\\launchSettings.json")
                    .Build();
                _httpsPort = launchJsonConfig.GetValue<int>("iisSettings:iisExpress:sslPort");

            }
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRouting(options => options.LowercaseUrls = true);

            
            // SQLServer Database 
            services.AddDbContext<MbdAppContext>(opt => opt.UseSqlServer(Configuration.GetConnectionString("DigitisationDatabase")));

            services.AddMvc(options => 
            {
                options.Filters.Add(typeof(LinkRewritingFilter));
                //Serialize Exceptions to Json 
                options.Filters.Add(typeof(JsonExceptionFilter));

                //Require Https for all controllers
                options.SslPort = _httpsPort;
                options.Filters.Add(typeof(RequireHttpsAttribute));
            });

            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));

            // Options for particular external services
            ConfigureOpenApi(services);
            ConfigureVersioning(services);
            ConfigureCors(services);
            ConfigureAppInfo(services);
            ConfigurePagingOptions(services);
            // Internal services
            
            services.AddScoped<IInvoicesMainService, DefaultInvoicesMainService>();
            services.AddScoped<IInvoicesDetailsService, DefaultInvoicesDetailsService>();
            services.AddScoped<IInvoicesVatService, DefaultInvoicesVatService>();
        }

        private void ConfigureCors(IServiceCollection services)
        { 
            services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigin",
                    builder => builder.WithOrigins("http://localhost:4200")
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
        }

        private void ConfigureOpenApi(IServiceCollection services)
        {
            services.AddSwagger();
        }

        private void ConfigureVersioning(IServiceCollection services)
        {
            services.AddApiVersioning(options =>
            {
                options.ApiVersionReader = new MediaTypeApiVersionReader();
                options.DefaultApiVersion = new ApiVersion(1, 0);
                options.AssumeDefaultVersionWhenUnspecified = true;
                // Includes headers "api-supported-versions" and "api-deprecated-versions"
                options.ReportApiVersions = true;
            });

            // Alternative to attribute based versioning
            //options.Conventions.Controller<GameServerController>()
            //    .HasDeprecatedApiVersion(new ApiVersion(0, 9))
            //    .HasApiVersion(1)
            //    .AdvertisesApiVersion(2)
            //    .Action(a => a.Get(default(int))).MapToApiVersion(1);

        }

        private void ConfigureAppInfo(IServiceCollection services)
        {
            services.Configure<AppInfo>(Configuration.GetSection("Info"));
        }

        private void ConfigurePagingOptions(IServiceCollection services)
        {
            services.Configure<PagingOptions>(Configuration.GetSection("DefaultPagingOptions"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                
            }


            // Shows UseCors with named policy.
            app.UseCors("AllowSpecificOrigin");

            // Enable the Swagger UI middleware and the Swagger generator.Do not expose Swagger Interface into production.

            app.UseSwaggerUi(typeof(Startup).GetTypeInfo().Assembly, settings =>
            {
                settings.SwaggerRoute = "/swagger/v1/swagger.json";
                settings.ShowRequestHeaders = true;
                settings.DocExpansion = "list";
                settings.UseJsonEditor = true;
                settings.GeneratorSettings.Description = "Building MBDApp WEB Api Project ";
                settings.GeneratorSettings.Title = "MBDApp Web Api";
                settings.GeneratorSettings.Version = "1.0";
               
                settings.GeneratorSettings.DefaultPropertyNameHandling =
                    PropertyNameHandling.CamelCase;

                settings.PostProcess = document =>
                {
                    document.BasePath = "/";
                    document.Info.Version = "v1";
                    document.Info.Title = "MBDApp API";
                    document.Info.Description = "MBDApp ASP.NET Core web API";
                    document.Info.TermsOfService = "None";
                    document.Info.Contact = new NSwag.SwaggerContact
                    {
                        Name = "Sebastian N Badea",
                        Email = "seb@masonbreese.com",
                        Url = ""
                    };
                    document.Info.License = new NSwag.SwaggerLicense
                    {
                        Name = "Use under LICX",
                        Url = "https://example.com/license"
                    };
                };
            });



            app.UseMvc();
        }

        
    }
}
