﻿using MBDAppWebApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi
{
    public class MbdAppContext : DbContext
    {
        public MbdAppContext(DbContextOptions options)
            : base(options) { }

        
        public DbSet<InvoicesDetailsEntity> InvoicesDetails { get; set; }
        public DbSet<InvoicesMainEntity> InvoicesMain { get; set; }
        public DbSet<InvoicesVatEntity> InvoicesVat { get; set; }
       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<InvoicesDetailsEntity>(entity =>
            {
                entity.HasKey(e => e.IdInvoiceDetails);

                entity.ToTable("InvoicesDetails", "dev");

                entity.HasIndex(e => e.IdInvoice)
                    .HasName("Idx_InvoicesDetails_IdInvoice");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Discount).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LedgerProbability).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Total).HasColumnType("money");

                entity.Property(e => e.UnitValue).HasColumnType("money");

                
            });

            modelBuilder.Entity<InvoicesMainEntity>(entity =>
            {
                entity.HasKey(e => e.IdInvoice);

                entity.ToTable("InvoicesMain", "dev");

                entity.Property(e => e.IdInvoice).ValueGeneratedNever();

                entity.Property(e => e.Account).IsUnicode(false);

                entity.Property(e => e.Client)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Currency)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.FileName).IsUnicode(false);

                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.Path).IsUnicode(false);

                entity.Property(e => e.Reciever).IsUnicode(false);

                entity.Property(e => e.Supplier)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.ValidationUser).IsUnicode(false);
            });

            modelBuilder.Entity<InvoicesVatEntity>(entity =>
            {
                entity.HasKey(e => e.IdInvoiceVat);

                entity.ToTable("InvoicesVat", "dev");

                entity.HasIndex(e => e.IdInvoice)
                    .HasName("Idx_InvoicesVat_IdInvoice");

                entity.Property(e => e.DescriptionVat)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.LedgerProbability).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PercentageVat).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ValueVat).HasColumnType("money");

               
            });
        }
    }
}
