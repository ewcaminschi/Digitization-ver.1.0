﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MBDAppWebApi.Models;
using MBDAppWebApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MBDAppWebApi.Controllers
{

    [Produces("application/json")]
    [Route("/[controller]")]
    public class InvoicesMainController : Controller
    {
        private readonly IInvoicesMainService _invoicesMainService;
        private readonly PagingOptions _defaultPagingOptions;
        private readonly IInvoicesDetailsService _invoicesDetailsService;

        public InvoicesMainController(
            IInvoicesMainService invoicesMainService,
            IInvoicesDetailsService invoicesDetailsService,
            IOptions<PagingOptions> defaultPagingOptions)
        {
            _invoicesMainService = invoicesMainService;
            _invoicesDetailsService = invoicesDetailsService;
            _defaultPagingOptions = defaultPagingOptions.Value;

        }
        //Get /invoicesMain
        [HttpGet(Name = nameof(GetInvoicesMainAsync))]
        public async Task<IActionResult> GetInvoicesMainAsync(
            [FromQuery] PagingOptions pagingOptions,
            [FromQuery] SortOptions<InvoicesMainResource, InvoicesMainEntity> sortOptions,
            [FromQuery] SearchOptions<InvoicesMainResource, InvoicesMainEntity> searchOptions,
            CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiError(ModelState));
            }

            pagingOptions.Offset = pagingOptions?.Offset ?? _defaultPagingOptions.Offset;
            pagingOptions.Limit = pagingOptions?.Limit ?? _defaultPagingOptions.Limit;

            var invoicesMain = await _invoicesMainService.GetInvoicesMainAsync(
                pagingOptions,
                sortOptions,
                searchOptions, ct);

            var collection = PagedCollection<InvoicesMainResource>.Create(
                Link.ToCollection(nameof(GetInvoicesMainAsync)),
                invoicesMain.Items.ToArray(),
                invoicesMain.TotalSize,
                pagingOptions);

            return Ok(collection);


        }

        //Get /invoicesMain/{IdInvoice}
        [HttpGet("{idInvoice}", Name = nameof(GetInvoicesMainByIdAsync))]
        public async Task<IActionResult> GetInvoicesMainByIdAsync(Guid idInvoice, CancellationToken ct)
        {
            var invoicesMain = await _invoicesMainService.GetInvoicesMainByIdAsync(idInvoice, ct);
            if (invoicesMain == null) return NotFound();


            return Ok(invoicesMain);
        }


        // TODO authentication!
        //Post /invoicesMain/{idInvoice}/invoicesdetails
        [HttpPost("{idInvoice}/invoicesdetails",Name = nameof(CreateInvoicesDetailsForInvoicesMainAsync))]
        public async Task<IActionResult> CreateInvoicesDetailsForInvoicesMainAsync(
            Guid idInvoice,
            [FromBody] InvoicesDetailsForm invoicesDetailsForm,
            CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiError(ModelState));
            }

            var invoiceMain = await _invoicesMainService.GetInvoicesMainByIdAsync(idInvoice, ct);
            if (invoiceMain == null) return NotFound();

            // Get the user ID (TODO)
            var userId = Guid.NewGuid();

            var idInvoiceVat = await _invoicesDetailsService.CreateInvoicesDetailsAsync(
                userId,
                idInvoice,
                invoicesDetailsForm.LineNumber,
                invoicesDetailsForm.Description,
                invoicesDetailsForm.Quantity,
                invoicesDetailsForm.UnitValue,
                invoicesDetailsForm.Discount,
                invoicesDetailsForm.Total,
                invoicesDetailsForm.Ledger,
                invoicesDetailsForm.LedgerProbability,
                ct
                );

            return Created(
                Url.Link(nameof(InvoicesDetailsController.GetInvoicesDetailsByIdAsync),
                new { idInvoiceVat }),
                null);


        }



        // TODO authentication!
        //Post /invoicesMain/
        [HttpPost( Name = nameof(CreateInvoicesMainAsync))]
        public async Task<IActionResult> CreateInvoicesMainAsync(
            [FromBody] InvoicesMainForm invoicesMainForm,
            CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiError(ModelState));
            }

            // Get the user ID (TODO)
            var userId = Guid.NewGuid();

            var invoicesMainId = await _invoicesMainService.CreateInvoicesMainAsync(
                userId,
                invoicesMainForm.Client,
                invoicesMainForm.Supplier, 
                invoicesMainForm.Reciever,
                invoicesMainForm.Number,
                invoicesMainForm.Date.Value,
                invoicesMainForm.Account,
                invoicesMainForm.Currency,
                invoicesMainForm.Path, 
                invoicesMainForm.FileName,
                invoicesMainForm.InvoiceStatus,
                invoicesMainForm.ValidationUser,
                invoicesMainForm.StartAt.Value,
                ct);

            return Created(
                Url.Link(nameof(this.GetInvoicesMainByIdAsync),
                new { invoicesMainId }),
                null);

        }
        //to do
        //Patch /invoicesMain/

    }

}