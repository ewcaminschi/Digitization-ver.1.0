﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MBDAppWebApi.Models;
using MBDAppWebApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MBDAppWebApi.Controllers
{
    [Produces("application/json")]
    [Route("/[controller]")]
    public class InvoicesVatController : Controller
    {
        private readonly IInvoicesVatService _invoicesVatService;
        private readonly PagingOptions _defaultPagingOptions;

        public InvoicesVatController(IInvoicesVatService invoicesVatService, IOptions<PagingOptions> defaultPagingOptions)
        {
            _invoicesVatService = invoicesVatService;
            _defaultPagingOptions = defaultPagingOptions.Value;
        }
        //Get /invoicesVat
        [HttpGet(Name = nameof(GetInvoicesVatAsync))]
        public async Task<IActionResult> GetInvoicesVatAsync(
            [FromQuery] PagingOptions pagingOptions,
            [FromQuery] SortOptions<InvoicesVatResource, InvoicesVatEntity> sortOptions,
            [FromQuery] SearchOptions<InvoicesVatResource, InvoicesVatEntity> searchOptions,
            CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiError(ModelState));
            }

            pagingOptions.Offset = pagingOptions?.Offset ?? _defaultPagingOptions.Offset;
            pagingOptions.Limit = pagingOptions?.Limit ?? _defaultPagingOptions.Limit;

            var invoicesVat = await _invoicesVatService.GetInvoicesVatAsync(
                pagingOptions,
                sortOptions,
                searchOptions, ct);

            var collection = PagedCollection<InvoicesVatResource>.Create(
                Link.ToCollection(nameof(GetInvoicesVatAsync)),
                invoicesVat.Items.ToArray(),
                invoicesVat.TotalSize,
                pagingOptions);

            return Ok(collection);


        }

        //Get /invoicesVat/{IdInvoiceVat}
        [HttpGet("{idInvoiceVat}", Name = nameof(GetInvoicesVatByIdAsync))]
        public async Task<IActionResult> GetInvoicesVatByIdAsync(Guid idInvoiceVat, CancellationToken ct)
        {
            var invoicesVat = await _invoicesVatService.GetInvoicesVatByIdAsync(idInvoiceVat, ct);
            if (invoicesVat == null) return NotFound();


            return Ok(invoicesVat);
        }
        // TODO authentication!
        //Post /invoicesMain/
        [HttpPost("{idInvoiceVat}", Name = nameof(CreateInvoicesVatAsync))]
        public async Task<IActionResult> CreateInvoicesVatAsync(
            int idInvoiceVat,
            [FromBody] DigitisationOutputForm digitisationOutputForm,
            CancellationToken ct)
        {
            throw new NotImplementedException();

        }

    }
}