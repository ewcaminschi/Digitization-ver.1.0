﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MBDAppWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MBDAppWebApi.Controllers
{
    [Produces("application/json")]
    [Route("/[controller]")]
    public class InfoController : Controller
    {
        private readonly AppInfo _appInfo;

        public InfoController(IOptions<AppInfo> appInfoAccessor)
        {
            _appInfo = appInfoAccessor.Value;
        }

        [HttpGet(Name = nameof(GetInfo))]
        public IActionResult GetInfo()
        {
            _appInfo.Href = Url.Link(nameof(GetInfo), null);

            return Ok(_appInfo);
        }
    }
}