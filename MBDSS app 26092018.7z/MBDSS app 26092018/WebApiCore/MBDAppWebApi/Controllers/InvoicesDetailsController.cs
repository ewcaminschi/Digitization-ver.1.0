﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MBDAppWebApi.Models;
using MBDAppWebApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MBDAppWebApi.Controllers
{
    [Produces("application/json")]
    [Route("/[controller]")]
    public class InvoicesDetailsController : Controller
    {
        private readonly IInvoicesDetailsService _invoicesDetailsService;
        private readonly PagingOptions _defaultPagingOptions;

        public InvoicesDetailsController(IInvoicesDetailsService invoicesDetailsService, IOptions<PagingOptions> defaultPagingOptions)
        {
            _invoicesDetailsService = invoicesDetailsService;
            _defaultPagingOptions = defaultPagingOptions.Value;
        }
        //Get /invoicesDetails
        [HttpGet(Name = nameof(GetInvoicesDetailsAsync))]
        public async Task<IActionResult> GetInvoicesDetailsAsync(
            [FromQuery] PagingOptions pagingOptions,
            [FromQuery] SortOptions<InvoicesDetailsResource, InvoicesDetailsEntity> sortOptions,
            [FromQuery] SearchOptions<InvoicesDetailsResource, InvoicesDetailsEntity> searchOptions,
            CancellationToken ct)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiError(ModelState));
            }

            pagingOptions.Offset = pagingOptions?.Offset ?? _defaultPagingOptions.Offset;
            pagingOptions.Limit = pagingOptions?.Limit ?? _defaultPagingOptions.Limit;

            var invoicesDetails = await _invoicesDetailsService.GetInvoicesDetailsAsync(
                pagingOptions,
                sortOptions,
                searchOptions, ct);

            var collection = PagedCollection<InvoicesDetailsResource>.Create(
                Link.ToCollection(nameof(GetInvoicesDetailsAsync)),
                invoicesDetails.Items.ToArray(),
                invoicesDetails.TotalSize,
                pagingOptions);

            return Ok(collection);


        }

        //Get /invoicesDetails/{InvoicesDetailsId}
        [HttpGet("{idInvoiceDetails}", Name = nameof(GetInvoicesDetailsByIdAsync))]
        public async Task<IActionResult> GetInvoicesDetailsByIdAsync(Guid idInvoiceDetails, CancellationToken ct)
        {
            var invoicesDetails = await _invoicesDetailsService.GetInvoicesDetailsByIdAsync(idInvoiceDetails, ct);
            if (invoicesDetails == null) return NotFound();


            return Ok(invoicesDetails);
        }
        // TODO authentication!
        //Post /invoicesDetails
        [HttpPost("{idInvoiceDetails}", Name = nameof(CreateInvoicesDetailsAsync))]
        public async Task<IActionResult> CreateInvoicesDetailsAsync(
            Guid idInvoiceDetails,
            [FromBody] InvoicesDetailsForm invoicesDetailsForm,
            CancellationToken ct)
        {
            throw new NotImplementedException();

        }

    }
}