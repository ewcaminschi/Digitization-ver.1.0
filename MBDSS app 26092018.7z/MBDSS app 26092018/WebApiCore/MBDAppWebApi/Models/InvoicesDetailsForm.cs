﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class InvoicesDetailsForm
    {
        [Required]
        [Display(Name = "lineNumber", Description = "Add description")]
        public int LineNumber { get; set; }

        [Required]
        [Display(Name = "description", Description = "Add description")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "quantity", Description = "Add description")]
        public int Quantity { get; set; }

        [Required]
        [Display(Name = "unitValue", Description = "Add description")]
        public decimal? UnitValue { get; set; }

        [Required]
        [Display(Name = "discount", Description = "Add description")]
        public decimal? Discount { get; set; }

        [Required]
        [Display(Name = "total", Description = "Add description")]
        public decimal? Total { get; set; }

        [Required]
        [Display(Name = "ledger", Description = "Add description")]
        public int? Ledger { get; set; }

        [Required]
        [Display(Name = "ledgerProbability", Description = "Add description")]
        public decimal? LedgerProbability { get; set; }
    }
}
