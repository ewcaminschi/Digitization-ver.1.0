﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class RootResource: Resource
    {
        public Link Info { get; set; }

        public Link InvoicesMain { get; set; }

        public Link InvoicesDetails { get; set; }

        public Link InvoicesVat { get; set; }

    }
}
