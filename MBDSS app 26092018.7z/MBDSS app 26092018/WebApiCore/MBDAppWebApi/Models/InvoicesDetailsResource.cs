﻿using MBDAppWebApi.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class InvoicesDetailsResource : Resource
    {
        [Sortable]
        [Searchable]
        public Guid IdInvoiceDetails { get; set; }

        [Sortable(Default = true)]
        public Guid IdInvoice { get; set; }
        public int LineNumber { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        [SearchableDecimal]
        public decimal? UnitValue { get; set; }
        public decimal? Discount { get; set; }
        public decimal? Total { get; set; }
        public int? Ledger { get; set; }
        public decimal? LedgerProbability { get; set; }
    }
}
