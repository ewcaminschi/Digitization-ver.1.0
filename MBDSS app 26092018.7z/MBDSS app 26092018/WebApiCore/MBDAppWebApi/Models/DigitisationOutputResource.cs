﻿using MBDAppWebApi.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class DigitisationOutputResource : Resource
    {
        [Sortable]
        [Searchable]
        public string OrganisationName { get; set; }

        [Sortable]
        [Searchable]
        public string SuplierName { get; set; }

        [Sortable]
        [Searchable]
        public string ClientName { get; set; }

        [Sortable(Default = true)]
        public string InvoiceNumber { get; set; }

        public DateTime? InvoiceDate { get; set; }
        public string InvoiceLineDescription { get; set; }
        public decimal? InvoiceLineValue { get; set; }
        public decimal? InvoiceLineVat { get; set; }
        public decimal? InvoiceLineQty { get; set; }
        public decimal? InvoiceLineTotal { get; set; }
        public decimal? InvoiceTotalExcludeVat { get; set; }
        public decimal? InvoiceTotalVat { get; set; }
        [SearchableDecimal]
        public decimal InvoiceTotal { get; set; }
        [Sortable]
        public int? Ledger { get; set; }
        public int? LedgerProbability { get; set; }
        public bool? Status { get; set; }
    }
}
