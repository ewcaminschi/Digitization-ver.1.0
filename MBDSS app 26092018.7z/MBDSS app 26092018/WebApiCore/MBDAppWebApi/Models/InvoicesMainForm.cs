﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class InvoicesMainForm
    {
        

        [Required]
        [Display(Name = "client", Description = "Add description")]
        public string Client { get; set; }

        [Required]
        [Display(Name = "supplier", Description = "Add description")]
        public string Supplier { get; set; }

        [Required]
        [Display(Name = "reciever", Description = "Add description")]
        public string Reciever { get; set; }

        [Required]
        [Display(Name = "number", Description = "Add description")]
        public string Number { get; set; }

        [Required]
        [Display(Name = "date", Description = "Add description")]
        public DateTime? Date { get; set; }

        [Required]
        [Display(Name = "account", Description = "Add description")]
        public string Account { get; set; }

        [Required]
        [Display(Name = "currency", Description = "Add description")]
        public string Currency { get; set; }

        [Required]
        [Display(Name = "path", Description = "Add description")]
        public string Path { get; set; }

        [Required]
        [Display(Name = "fileName", Description = "Add description")]
        public string FileName { get; set; }

        [Required]
        [Display(Name = "invoiceStatus", Description = "Add description")]
        public int? InvoiceStatus { get; set; }

        [Required]
        [Display(Name = "validationUser", Description = "Add description")]
        public string ValidationUser { get; set; }

        [Display(Name = "startAt", Description = "Booking start time")]
        public DateTimeOffset? StartAt { get; set; }
    }
}
