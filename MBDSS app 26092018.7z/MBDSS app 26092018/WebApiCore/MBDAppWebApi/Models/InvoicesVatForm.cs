﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class InvoicesVatForm
    {
        [Required]
        [Display(Name = "idInvoiceVat", Description = "Add description")]
        public int IdInvoiceVat { get; set; }

        [Required]
        [Display(Name = "idInvoice", Description = "Add description")]
        public int IdInvoice { get; set; }

        [Required]
        [Display(Name = "descriptionVat", Description = "Add description")]
        public string DescriptionVat { get; set; }

        [Required]
        [Display(Name = "percentageVat", Description = "Add description")]
        public decimal? PercentageVat { get; set; }

        [Required]
        [Display(Name = "valueVat", Description = "Add description")]
        public decimal? ValueVat { get; set; }

        [Required]
        [Display(Name = "ledger", Description = "Add description")]
        public int? Ledger { get; set; }

        [Required]
        [Display(Name = "ledgerProbability", Description = "Add description")]
        public decimal? LedgerProbability { get; set; }
    }
}
