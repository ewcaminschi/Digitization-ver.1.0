﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class DigitisationOutputForm
    {

        //  public Guid Id { get; set; }

        [Required]
        [Display(Name = "organisationName", Description = "Add description")]
        public string OrganisationName { get; set; }

        [Required]
        [Display(Name = "suplierName", Description = "Add description")]
        public string SuplierName { get; set; }

        [Required]
        [Display(Name = "clientName", Description = "Add description")]
        public string ClientName { get; set; }

        [Required]
        [Display(Name = "invoiceNumber", Description = "Add description")]
        public string InvoiceNumber { get; set; }

        [Required]
        [Display(Name = "invoiceDate", Description = "Add description")]
        public DateTime? InvoiceDate { get; set; }

        [Required]
        [Display(Name = "invoiceLineDescription", Description = "Add description")]
        public string InvoiceLineDescription { get; set; }

        [Required]
        [Display(Name = "invoiceLineValue", Description = "Add description")]
        public decimal? InvoiceLineValue { get; set; }

        [Required]
        [Display(Name = "invoiceLineVat", Description = "Add description")]
        public decimal? InvoiceLineVat { get; set; }

        [Required]
        [Display(Name = "invoiceLineQty", Description = "Add description")]
        public decimal? InvoiceLineQty { get; set; }

        [Required]
        [Display(Name = "invoiceLineTotal", Description = "Add description")]
        public decimal? InvoiceLineTotal { get; set; }

        [Required]
        [Display(Name = "invoiceTotalExcludeVat", Description = "Add description")]
        public decimal? InvoiceTotalExcludeVat { get; set; }

        [Required]
        [Display(Name = "invoiceTotalVat", Description = "Add description")]
        public decimal? InvoiceTotalVat { get; set; }

        [Required]
        [Display(Name = "invoiceTotal", Description = "Add description")]
        public decimal InvoiceTotal { get; set; }

        [Required]
        [Display(Name = "ledger", Description = "Add description")]
        public int? Ledger { get; set; }

        [Required]
        [Display(Name = "ledgerProbability", Description = "Add description")]
        public int? LedgerProbability { get; set; }

        [Required]
        [Display(Name = "status", Description = "Add description")]
        public bool? Status { get; set; }

       
    }
}
