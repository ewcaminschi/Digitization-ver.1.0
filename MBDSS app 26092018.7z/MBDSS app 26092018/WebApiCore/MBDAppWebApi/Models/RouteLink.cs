﻿using Newtonsoft.Json;

namespace MBDAppWebApi.Models
{
    public class RouteLink : Link
    {
        [JsonIgnore]
        public string RouteName { get; set; }

        [JsonIgnore]
        public object RouteValues { get; set; }
    }
}
