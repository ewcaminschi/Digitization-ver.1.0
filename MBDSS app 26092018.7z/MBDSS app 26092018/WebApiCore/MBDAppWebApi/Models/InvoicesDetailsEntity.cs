﻿using System;

namespace MBDAppWebApi.Models
{
    public class InvoicesDetailsEntity
    {
        public Guid IdInvoiceDetails { get; set; }
        public Guid IdInvoice { get; set; }
        public int LineNumber { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal? UnitValue { get; set; }
        public decimal? Discount { get; set; }
        public decimal? Total { get; set; }
        public int? Ledger { get; set; }
        public decimal? LedgerProbability { get; set; }
    }
}
