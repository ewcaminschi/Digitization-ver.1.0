﻿using MBDAppWebApi.Infrastructure;
using System;


namespace MBDAppWebApi.Models
{
    public class InvoicesMainResource : Resource
    {
        [Sortable]
        [Searchable]
        public Guid IdInvoice { get; set; }
        public string Client { get; set; }
        public string Supplier { get; set; }
        public string Reciever { get; set; }
        [Sortable(Default = true)]
        public string Number { get; set; }
        public DateTime? Date { get; set; }
        public string Account { get; set; }
        public string Currency { get; set; }
        public string Path { get; set; }
        public string FileName { get; set; }
        public int? InvoiceStatus { get; set; }
        public string ValidationUser { get; set; }
    }
}
