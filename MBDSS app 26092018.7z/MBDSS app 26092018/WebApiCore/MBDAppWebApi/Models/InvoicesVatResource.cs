﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class InvoicesVatResource : Resource
    {
        public Guid IdInvoiceVat { get; set; }
        public Guid IdInvoice { get; set; }
        public string DescriptionVat { get; set; }
        public decimal? PercentageVat { get; set; }
        public decimal? ValueVat { get; set; }
        public int? Ledger { get; set; }
        public decimal? LedgerProbability { get; set; }
    }
}
