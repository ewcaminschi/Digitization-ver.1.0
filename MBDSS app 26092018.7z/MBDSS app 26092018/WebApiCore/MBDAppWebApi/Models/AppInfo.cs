﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MBDAppWebApi.Models
{
    public class AppInfo : Resource
    {
        public string Title { get; set; }

        public string Desc { get; set; }
    }
}
