﻿using AutoMapper;
using MBDAppWebApi.Controllers;
using MBDAppWebApi.Models;

namespace MBDAppWebApi.Infrastructure
{
    public class MappingProfile : Profile 
    {
        public MappingProfile()
        {
            CreateMap<InvoicesMainEntity, InvoicesMainResource>()

               .ForMember(dest => dest.Self, opt => opt.MapFrom(src => Link.To(
                nameof(InvoicesMainController.GetInvoicesMainByIdAsync), new { invoicesMainId = src.IdInvoice })));

            CreateMap<InvoicesDetailsEntity, InvoicesDetailsResource>()

              .ForMember(dest => dest.Self, opt => opt.MapFrom(src => Link.To(
               nameof(InvoicesDetailsController.GetInvoicesDetailsByIdAsync), new { invoicesDetailsId = src.IdInvoiceDetails })));

            CreateMap<InvoicesVatEntity, InvoicesVatResource>()

             .ForMember(dest => dest.Self, opt => opt.MapFrom(src => Link.To(
              nameof(InvoicesVatController.GetInvoicesVatByIdAsync), new { invoicesVatId = src.IdInvoiceVat})));
        }


        
        

        
    }
}
